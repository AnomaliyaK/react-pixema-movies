import React from 'react';
import styled from 'styled-components';

export const HomePage = () => {
    return (
        <Container>
            <Title>HomePage</Title>
        </Container>
    );
};

const Container = styled.div`
    display: grid;
    place-items: center;
    flex-grow: 1;
    background-color: palegoldenrod;
`;

const Title = styled.h1`
    font-size: 2rem;
    text-transform: uppercase;
`;
