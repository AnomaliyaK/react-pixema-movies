import React from 'react';
import styled from 'styled-components';

export const AboutPage = () => {
    return (
        <Container>
            <Title>AboutPage</Title>
        </Container>
    );
};

const Container = styled.div`
    display: grid;
    place-items: center;
    flex-grow: 1;
    background-color: coral;
`;

const Title = styled.h1`
    font-size: 2rem;
    text-transform: uppercase;
`;
