import { createBrowserRouter, createRoutesFromElements, Route } from 'react-router-dom';
import { AboutPage } from '../pages/AboutPage';
import { ContactsPage } from '../pages/ContactsPage';
import { HomePage } from '../pages/HomePage';
import { MainTemplate } from '../templates/MainTemplate';
import { ROUTE } from './routes';

export const router = createBrowserRouter(
    createRoutesFromElements(
        <Route path={ROUTE.HOME} element={<MainTemplate />}>
            <Route index element={<HomePage />} />
            <Route path={ROUTE.ABOUT} element={<AboutPage />} />
            <Route path={ROUTE.CONTACTS} element={<ContactsPage />} />
        </Route>
    )
);
