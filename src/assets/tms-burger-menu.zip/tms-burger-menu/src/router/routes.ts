export enum ROUTE {
    HOME = '/',
    ABOUT = '/about',
    CONTACTS = '/contacts',
}
