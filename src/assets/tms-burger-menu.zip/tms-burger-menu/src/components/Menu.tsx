import { motion } from 'framer-motion';
import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import { ROUTE } from '../router/routes';

interface MenuProps {
    isOpen: boolean;
    isMobile: boolean;
    handleClose: () => void;
}

const menuVariants = {
    open: { opacity: 1, x: 0 },
    closed: { opacity: 0, x: '-100%' },
    idle: {},
};

export const Menu = ({ isOpen, isMobile, handleClose }: MenuProps) => {
    const currentVariant = isMobile ? (isOpen ? 'open' : 'closed') : 'idle';
    return (
        <StyledNav animate={currentVariant} variants={menuVariants} initial="idle">
            <Link to={ROUTE.HOME} onClick={handleClose}>
                Home
            </Link>
            <Link to={ROUTE.ABOUT} onClick={handleClose}>
                About
            </Link>
            <Link to={ROUTE.CONTACTS} onClick={handleClose}>
                Contacts
            </Link>
        </StyledNav>
    );
};

const StyledNav = styled(motion.nav)`
    display: flex;
    gap: 1rem;

    @media (max-width: 568px) {
        position: absolute;
        top: 100px;
        left: 0;
        z-index: 10;

        flex-direction: column;
        align-items: center;
        justify-content: center;

        width: 100vw;
        height: calc(100vh - 100px);
        background-color: inherit;
        opacity: 0;
        transform: translateX(-100%);
    }
`;
