import styled from 'styled-components';
import { useToggle } from '../hooks/useToggle';
import { useWindowSize } from '../hooks/useWindowSize';
import { BurgerMenu } from './BurgerMenu';
import { Menu } from './Menu';

export const Header = () => {
    const [isMenuOpen, toggleMenu] = useToggle();
    const { width = 0 } = useWindowSize();
    const isMobile = width < 568;

    return (
        <StyledHeader>
            <Title>Logo</Title>
            <Menu isOpen={isMenuOpen} isMobile={isMobile} handleClose={toggleMenu} />
            {isMobile && <BurgerMenu toggleMenu={toggleMenu} isMenuOpen={isMenuOpen} />}
        </StyledHeader>
    );
};

const StyledHeader = styled.header`
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1rem;
    background-color: lightblue;
`;

const Title = styled.h1`
    font-size: 2rem;
    text-transform: uppercase;
`;
